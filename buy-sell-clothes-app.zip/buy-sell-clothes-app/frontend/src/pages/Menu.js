import React from 'react';
import MenuList from '../components/menu/MenuList';

const Menu = () => {
  return (
    <div>
      <MenuList />
    </div>
  );
};

export default Menu;