import React from 'react';
import OrderForm from '../components/order/OrderForm';

const Order = () => {
  return (
    <div>
      <OrderForm />
    </div>
  );
};

export default Order;